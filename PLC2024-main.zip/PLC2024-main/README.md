# Programming Language Concepts code for Aston University students
```diff
- This repo is the PLC module starting in January 2024.
- For a module begining in later years please use the relevant
- GitHub repo for that year.
```
## Editing and running the code via a web browser

- Make an account on [gitpod.io](https://gitpod.io)
- Open an IDE using [this link](https://gitpod.io/#https://github.com/hassanaqeelkhan/PLC2022_test).

## Editing and running the code on own computer via Docker

- Please see the instructions on Blackboard under [Learning Resources](https://vle.aston.ac.uk/webapps/blackboard/content/listContentEditable.jsp?content_id=_2383294_1&course_id=_36175_1&mode=reset)
