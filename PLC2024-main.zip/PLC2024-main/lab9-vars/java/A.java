class A { A left; A right; }
