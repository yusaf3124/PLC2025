// Header file for input output functions
#include <stdio.h>
// main function -
int main()
{ 
    // prints hello world
    printf("Hello World\n"); 
    return 0;
}